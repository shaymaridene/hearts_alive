#include <gtk/gtk.h>


void
on_AHD_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_GRV_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_M_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_home1_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_return1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_return2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_home2_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rmod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_home3_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_return3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Cmod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_home4_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_return4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_A_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_home5_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_return5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_return6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_home6_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Csupp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_adc_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_return7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_home7_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_supp_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_A_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_historique_RDV_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_AfficheurdonRDV_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_hist_rdv_gest_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton4_rdv_mod_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_rdv_mod_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_rdv_mod_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_rdv_mod_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton6_rdv_A_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton5_rdv_A_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton7_rdv_A_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton8_rdv_A_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_stat_rdv_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_rdv_home_stat_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_rdv_home_stat_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_rdv_stat_clicked            (GtkButton       *button,
                                        gpointer         user_data);



void
on_treeview1_tree_don_cin_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_tree_don_clicked            (GtkButton       *button,
                                        gpointer         user_data);
